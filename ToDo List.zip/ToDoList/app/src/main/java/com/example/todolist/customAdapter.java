package com.example.todolist;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

public class customAdapter extends BaseAdapter {

    Context mcontext;
    MainActivity ma = new MainActivity();
    ArrayList<items> arrayList;
    private AdapterView.OnItemClickListener onItemClickListener;

    customAdapter(Context context,ArrayList<items> arrayList){
        this.arrayList=arrayList;
        this.mcontext=context;
    }

    @Override
    public int getCount() {
        return this.arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) { return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_layout,null);
            TextView tvName = (TextView) convertView.findViewById(R.id.tv_name);
            TextView tvDate = (TextView)convertView.findViewById(R.id.tv_date);
            final CheckBox cbMainItem = (CheckBox) convertView.findViewById(R.id.cb_mainitem);
            final items itm = arrayList.get(position);
            final String itmname = itm.getName();
            String isCheckedYN = itm.getISCHECKEDYN();
            final String name = itm.getName();
            tvName.setText(itm.getName());
            tvDate.setText(itm.getDuedate());
            cbMainItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(cbMainItem.isChecked()){
                       // Log.i(TAG,name+" item checked");
                        ma.updateFlag(name,"Y");
                    }
                    else {
                        //Log.i(TAG,"item unchecked");
                        ma.updateFlag(name,"N");
                    }
                }
            });
            if(isCheckedYN!=null) {
                if (isCheckedYN.equalsIgnoreCase("Y")) {
                    cbMainItem.setChecked(true);
                } else {
                    cbMainItem.setChecked(false);
                }
            }

        }
        return convertView;
    }
    public void setOnItemClickListener(AdapterView.OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }
}
