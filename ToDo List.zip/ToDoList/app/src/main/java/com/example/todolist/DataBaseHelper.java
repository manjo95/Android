package com.example.todolist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String TAG = "DataBaseHelper";
    public DataBaseHelper(Context context) {
        super(context,"mainItem.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE ITEMTABLE(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,DUEDATE TEXT,ISCHECKEDYN TEXT)");

        db.execSQL("CREATE TABLE ITEMTABLE2(ID_ITEM INTEGER PRIMARY KEY AUTOINCREMENT,SZNAME TEXT,SZITEMNAME TEXT,CCOMPLETEDYN TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS ITEMTABLE");
        db.execSQL("DROP TABLE IF EXISTS ITEMTABLE2");
        onCreate(db);
    }
    public boolean addData(String name,String duedate){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        ContentValues cv = new ContentValues();
        contentValues.put("NAME", name);
        contentValues.put("DUEDATE",duedate);
        contentValues.put("ISCHECKEDYN","N");
        cv.put("SZNAME",name);
        cv.put("CCOMPLETEDYN","X");
        long result = db.insert("ITEMTABLE", null, contentValues);
        long result2 = db.insert("ITEMTABLE2",null,cv);
        if(result2 == -1){

            Log.e("DatabaseHelper","not inserted into table");
        }
        else{
            Log.i("DatabaseHelper","Inserted into the table 2");
        }

        //if inserted incorrectly it will return -1
        if (result == -1 && result2 == -1) {
            return false;
        } else {
            return true;
        }

    }
    public boolean addItemData(String szName, String szItemName){
        Log.i(TAG,"In addItemData method -----> szName:"+szName+" szItemName:"+szItemName);
        SQLiteDatabase db2 = this.getWritableDatabase();
        ContentValues cv2 = new ContentValues();
        cv2.put("SZNAME",szName);
        cv2.put("SZITEMNAME",szItemName);
        cv2.put("CCOMPLETEDYN","N");
        long result = db2.insert("ITEMTABLE2",null,cv2);
        Log.i("DatabaseHelper","addItemData:"+result);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }

    }

    public ArrayList<items> getData(){
        Log.i("DatabaseHelper","Inside the DatabaseHelper.getData method");
        ArrayList<items> arrayList = new ArrayList<>();
        SQLiteDatabase sdb = this.getReadableDatabase();
        Cursor cursor = sdb.rawQuery("SELECT * FROM ITEMTABLE",null);

        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String completedyn = cursor.getString(3);


            items itemsObj = new items(id,name,date,completedyn);
            arrayList.add(itemsObj);
        }
        cursor.close();

        return arrayList;
    }
    public ArrayList<itemAdd2> getItemData(String name){
        Log.i("DatabaseHelper","Inside the DatabaseHelper.getItemData method");
        StringBuilder sb = new StringBuilder();
        ArrayList<itemAdd2> arrayList2 = new ArrayList<>();
        String var = "X";
        String[] args = new String[]{ name, var };
        SQLiteDatabase sdb = this.getReadableDatabase();
        //+"AND CCOMPLETEDYN='X'"
        //        Cursor cursor = sdb.rawQuery("SELECT * FROM ITEMTABLE2 WHERE SZNAME='"+name+"'"+" AND CCOMPLETEDYN='N'"+" OR CCOMPLETEDYN='Y'",null);
        Cursor cursor = sdb.rawQuery("SELECT * FROM ITEMTABLE2 WHERE SZNAME='"+name+"'"+" AND CCOMPLETEDYN <> 'X' ",null);
        //Cursor cursor = sdb.rawQuery("SELECT * FROM ITEMTABLE2 WHERE CCOMPLETEDYN<>'X'",null);
        //Cursor cursor = sdb.query("ITEMTABLE2",null,"SZNAME=? AND CCOMPLETEDYN<>?", args,null);
        while(cursor.moveToNext()){
            Log.i("DatabaseHelper","Inside the DatabaseHelper.getItemData-while method");
            int id = cursor.getInt(0);

            String szName = cursor.getString(1);
            String szItemName = cursor.getString(2);
            Log.i("DatabaseHelper","in getItemData method-->the szItemName is:"+szItemName);
            String cCompletedYN = cursor.getString(3);

            itemAdd2 items2Obj = new itemAdd2(id,szName,szItemName,cCompletedYN);
            arrayList2.add(items2Obj);
            Log.v(TAG,String.format("Printing the cursor Row: %d, Values: %s", cursor.getPosition(),
                    sb.toString()));
        }

        cursor.close();

        return arrayList2;
    }
    public ArrayList<String> checkName(){
        Log.i("DatabaseHelper","Inside the DatabaseHelper.getData method");
        ArrayList<String> arrayList = new ArrayList<>();
        SQLiteDatabase sdb = this.getReadableDatabase();
        Cursor cursor = sdb.rawQuery("SELECT * FROM ITEMTABLE",null);

        while(cursor.moveToNext()){
            String name = cursor.getString(1);

            arrayList.add(name);
        }
        cursor.close();

        return arrayList;
    }

    public ArrayList<String> checkItemName(String mName){
        Log.i("DatabaseHelper","Inside the DatabaseHelper.getData method");
        ArrayList<String> arrayList = new ArrayList<>();
        SQLiteDatabase sdb = this.getReadableDatabase();
        Cursor cursor = sdb.rawQuery("SELECT SZITEMNAME FROM ITEMTABLE2 WHERE SZNAME='"+mName+"'",null);

        while(cursor.moveToNext()){
            String name = cursor.getString(0);

            arrayList.add(name);
        }
        cursor.close();

        return arrayList;
    }

    public void updateItemFlag(String Name,String Flag)
    {
        ContentValues values = new ContentValues();
        values.put("CCOMPLETEDYN", Flag);
        String where="SZITEMNAME = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        db.update("ITEMTABLE2",values, where, new String[]{Name});
        db.close();
    }

    public void updateFlag(String Name,String Flag){
        ContentValues values = new ContentValues();
        values.put("ISCHECKEDYN", Flag);
        String where="NAME = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        db.update("ITEMTABLE",values, where, new String[]{Name});
        db.close();
    }




}
