package com.example.todolist;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomAdapter_addItem extends BaseAdapter {
    Context mcontext;
    ArrayList<itemAdd2> arrayList;
    additems adt = new additems();
    //DataBaseHelper dbHelper = new DataBaseHelper(additems.class);
    //String name="";
    public static final String TAG = "CustomAdapter_addItem";

    public CustomAdapter_addItem(Context mcontext, ArrayList<itemAdd2> arrayList) {
        this.mcontext = mcontext;
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {return this.arrayList.size();}

    @Override
    public Object getItem(int position) {return arrayList.get(position);}

    @Override
    public long getItemId(int position) {return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_additem_layout,null);
            TextView tv_addItem2 = (TextView) convertView.findViewById(R.id.tv_addItem2);
            final CheckBox cb_addItem2 = (CheckBox) convertView.findViewById(R.id.cb_addItem2);
            final itemAdd2 itm2 = arrayList.get(position);
            tv_addItem2.setText(itm2.getSzItemName());
            final String name = itm2.getSzItemName();
            //cb_addItem2.setText(itm2.getcCompletedYN());
            //cb_addItem2.setChecked(true);
            cb_addItem2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(cb_addItem2.isChecked()){
                        Log.i(TAG,name+" item checked");
                        additems.updateItemFlag(name,"Y");
                    }
                    else {
                        Log.i(TAG,"item unchecked");
                        additems.updateItemFlag(name,"N");
                    }
                }
            });
            if(itm2.getcCompletedYN().equalsIgnoreCase("Y")){
                cb_addItem2.setChecked(true);
            }
            else{
                cb_addItem2.setChecked(false);
            }

        }
        return convertView;

    }

}
