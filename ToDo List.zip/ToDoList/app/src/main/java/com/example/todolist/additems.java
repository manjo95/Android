package com.example.todolist;

import android.app.AlertDialog;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class additems extends AppCompatActivity {
    static DataBaseHelper dataBaseHelper;
    String szItemName,mName;
    private ListView lv_addItems2;
    ArrayList<itemAdd2> arrayList;
    CustomAdapter_addItem cadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additems);
        dataBaseHelper = new DataBaseHelper(this);
        mName = getIntent().getStringExtra("mName");
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(mName);
        setSupportActionBar(toolbar);
        lv_addItems2 = (ListView)findViewById(R.id.lv_addItems2);
        arrayList = new ArrayList<>();
        showData(mName);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                       // .setAction("Action", null).show();
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(additems.this);
                View mView = getLayoutInflater().inflate(R.layout.additem_dialog_layout, null);
                final EditText mEtDialog = (EditText) mView.findViewById(R.id.etDialog);
                Button mAdd = (Button) mView.findViewById(R.id.btndialog);
                mBuilder.setView(mView);
                final AlertDialog dialog = mBuilder.create();
                dialog.show();
                mAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        szItemName = mEtDialog.getText().toString();
                        if(!szItemName.isEmpty()){
                            if(checkItemData(szItemName,mName)) {
                                Log.i("additems", "in OnCreate method->szItemName:" + szItemName + "mName:" + mName);
                                AddEntry(mName, szItemName);
                                // Snackbar.make(v, szItemName, Snackbar.LENGTH_LONG)
                                //  .setAction("Action", null).show();
                                finish();
                                overridePendingTransition(0, 0);
                                startActivity(getIntent());
                                overridePendingTransition(0, 0);
                            }else{
                                toastMessage("Item name already exists");
                            }
                        }
                    }
                });
            }
        });
    }
    private void showData(String name) {
        Log.i("additems.java","inside show data "+name);
        //arrayList = new ArrayList<>();
        arrayList = dataBaseHelper.getItemData(name);
        cadapter = new CustomAdapter_addItem(this,arrayList);
        lv_addItems2.setAdapter(cadapter);
        cadapter.notifyDataSetChanged();
    }
    public void AddEntry(String szName, String szItemName){
        Log.i("additems","In AddEntry method--->szName:"+szName+" szItemName:"+szItemName);
        boolean insertData = dataBaseHelper.addItemData(szName,szItemName);

        if (insertData) {
            toastMessage("Added Successfully!");
        } else {
            toastMessage("Something went wrong");
        }
    }
    public static void updateItemFlag(String name, String flag){
        dataBaseHelper.updateItemFlag(name,flag);
    }

    public boolean checkItemData(String name, String mName){
        ArrayList<String> alname = new ArrayList<>();
        alname = dataBaseHelper.checkItemName(mName);
        if((!alname.isEmpty())&& (alname.contains(name))){
            return false;
        }
        else{
            return true;
        }

    }
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

}
