package com.example.todolist;

public class items {
    int id;
    String name;
    String duedate;

    String ISCHECKEDYN;

    public items(int id, String name, String duedate, String ISCHECKEDYN) {
        this.id = id;
        this.name = name;
        this.duedate = duedate;
        this.ISCHECKEDYN=ISCHECKEDYN;
    }
    public items(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDuedate() {
        return duedate;
    }

    public void setDuedate(String duedate) {
        this.duedate = duedate;
    }

    public String getISCHECKEDYN() {
        return ISCHECKEDYN;
    }

    public void setISCHECKEDYN(String ISCHECKEDYN) {
        this.ISCHECKEDYN = ISCHECKEDYN;
    }
}
