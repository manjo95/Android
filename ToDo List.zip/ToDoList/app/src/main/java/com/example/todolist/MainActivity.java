package com.example.todolist;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private EditText etName,etDate;
    private ListView lvmain;
    private Button btn1;
    Button tvName;
    static DataBaseHelper dataBaseHelper;
    ArrayList<items> arrayList;

    customAdapter cadapter;
    String mName;
    Calendar calendar = Calendar.getInstance();
    final int year = calendar.get(Calendar.YEAR);
    final int month = calendar.get(Calendar.MONTH);
    final int day = calendar.get(Calendar.DAY_OF_MONTH);
    DatePickerDialog.OnDateSetListener setlistener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataBaseHelper = new DataBaseHelper(this);
        etName = (EditText)findViewById(R.id.editText_name);
        etDate = (EditText)findViewById(R.id.editText_duedate);
        lvmain = (ListView)findViewById(R.id.listView_itemMain);
        btn1 = (Button)findViewById(R.id.button_addItem);
        arrayList = new ArrayList<>();
        //showData();

        arrayList = dataBaseHelper.getData();
        cadapter = new customAdapter(this,arrayList);
        lvmain.setAdapter(cadapter);
        cadapter.notifyDataSetChanged();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String et_name = etName.getText().toString();
                String et_date = etDate.getText().toString();
                if (et_name.length() != 0) {
                    if(checkData(et_name)) {
                        AddEntry(et_name, et_date);
                        etName.setText("");
                        etDate.setText("");
                    }else{
                        toastMessage("Name already exists");
                    }
                } else {
                    toastMessage("The Item can not be Empty!");
                }
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);

            }
        });
        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd =new DatePickerDialog(MainActivity.this,android.R.style.Theme,setlistener,year,month,day);
                dpd.show();
            }
        });
        setlistener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month+1;
                String date= day+"/"+month+"/"+year;
                etDate.setText(date);
            }
        };


        lvmain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                items mItem = (items) cadapter.getItem(position);
                mName = mItem.name;
                Intent intent = new Intent(MainActivity.this,additems.class);
                intent.putExtra("mName",mName);
                startActivity(intent);
                toastMessage(mName);
            }
        });
        lvmain.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                items mItem = (items) cadapter.getItem(position);
                mName = mItem.name;
                toastMessage("Longpressed "+ mName);
                return false;
            }
        });

    }

    private void showData() {
        arrayList = dataBaseHelper.getData();
        cadapter = new customAdapter(this,arrayList);
        lvmain.setAdapter(cadapter);
        cadapter.notifyDataSetChanged();
    }
    public void AddEntry(String name,String date){
        boolean insertData = dataBaseHelper.addData(name,date);

        if (insertData) {
            toastMessage("Item added Successfully!");
        } else {
            toastMessage("Something went wrong");
        }
    }

    public boolean checkData(String name){
        ArrayList<String> alname = new ArrayList<>();
        alname = dataBaseHelper.checkName();
        if((!alname.isEmpty())&& (alname.contains(name))){
           return false;
        }
        else{
            return true;
        }

    }
    /*public void btnclkd(String name){
        //items mItem = (items) cadapter.getItem(name);
        mName = name;
        Intent intent = new Intent(this,additems.class);
        intent.putExtra("mName",mName);
        startActivity(intent);
        toastMessage(mName);
    }*/

    public static void updateFlag(String name, String flag){
        dataBaseHelper.updateFlag(name,flag);
    }


    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

}
