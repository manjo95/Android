package com.example.todolist;

public class itemAdd2 {
    String szName,szItemName,cCompletedYN;
    int Id;


    public itemAdd2(int Id,String szName, String szItemName, String cCompletedYN) {
        this.Id = Id;
        this.szName = szName;
        this.szItemName = szItemName;
        this.cCompletedYN = cCompletedYN;
    }

    public itemAdd2() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getSzName() {
        return szName;
    }

    public void setSzName(String szName) {
        this.szName = szName;
    }

    public String getSzItemName() {
        return szItemName;
    }

    public void setSzItemName(String szItemName) {
        this.szItemName = szItemName;
    }

    public String getcCompletedYN() {
        return cCompletedYN;
    }

    public void setcCompletedYN(String cCompletedYN) {
        this.cCompletedYN = cCompletedYN;
    }
}
