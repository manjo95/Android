package com.example.todolist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DBAdapterItem {
    public static final String TAG = "DBAdapterItem";
    private Context mContext;
    private SQLiteDatabase mDatabase;
    private DataBaseHelper mDbHelper;
    private String[] mAllColumns = {"ID_ITEM","SZNAME","SZITEMNAME","CCOMPLETEDYN"};

    public DBAdapterItem(Context context) {
        mDbHelper = new DataBaseHelper(context);
        this.mContext = context;
        // open the database
        try {
            open();
        } catch (SQLException e) {
            Log.e(TAG, "SQLException on DBAdapterItem.open() " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void open() throws SQLException {
        mDatabase = mDbHelper.getWritableDatabase();
    }

    public void close() {
        mDbHelper.close();
    }
    public itemAdd2 addItemData(String szName, String szItemName){
        ContentValues cv2 = new ContentValues();
        cv2.put("SZNAME",szName);
        cv2.put("SZITEMNAME",szItemName);
        long insertId = mDatabase.insert("ITEMTABLE2", null, cv2);
        Cursor cursor = mDatabase.rawQuery("SELECT * FROM ITEMTABLE2",null);
        cursor.moveToFirst();
        itemAdd2 itemsadd = cursorToItem(cursor);
        cursor.close();
        return itemsadd;

    }
    private itemAdd2 cursorToItem(Cursor cursor) {
        itemAdd2 itemsadd = new itemAdd2();
        itemsadd.setId(cursor.getInt(0));
        itemsadd.setSzName(cursor.getString(1));
        itemsadd.setSzItemName(cursor.getString(2));
        itemsadd.setcCompletedYN(cursor.getString(3));
        return itemsadd;
    }

}
